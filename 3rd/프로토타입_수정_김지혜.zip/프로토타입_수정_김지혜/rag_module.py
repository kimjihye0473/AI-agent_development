import os
import tempfile
from langchain_community.document_loaders import PyMuPDFLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

def build_vector_store(uploaded_files):
    """
    업로드된 파일들을 로드하고 청크로 나누어 FAISS 벡터 스토어를 구축합니다.
    """
    docs = []
    for file in uploaded_files:
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.name)[1]) as tmp:
            tmp.write(file.getvalue())
            tmp_path = tmp.name

        try:
            if file.name.endswith(".pdf"):
                loader = PyMuPDFLoader(tmp_path)
                docs.extend(loader.load())
            elif file.name.endswith(".txt"):
                loader = TextLoader(tmp_path, encoding="utf-8")
                docs.extend(loader.load())
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)

    if not docs:
        return None

    text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
    splits = text_splitter.split_documents(docs)
    
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(splits, embeddings)
    return vectorstore

def search_documents(vectorstore, query: str) -> str:
    """
    벡터 스토어에서 사용자의 쿼리와 관련된 문서를 검색하여 텍스트로 반환합니다.
    """
    if not vectorstore:
        return ""
    docs = vectorstore.similarity_search(query, k=3)
    return "\n---\n".join([doc.page_content for doc in docs])