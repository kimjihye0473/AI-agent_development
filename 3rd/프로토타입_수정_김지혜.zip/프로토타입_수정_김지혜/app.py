import os
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from openai import OpenAI

api_key = os.environ.get("OPENAI_API_KEY", "")
client = OpenAI(api_key=api_key)
MODEL_NAME = "gpt-4o-mini"

app = FastAPI(title="인트라AI")

class TaskRequest(BaseModel):
    prompt: str
    system_prompt: str
    max_tokens: int = 1000

@app.post("/api/ai")
async def ai_endpoint(req: TaskRequest):
    try:
        if not api_key:
            raise HTTPException(status_code=500, detail="OpenAI API 키가 설정되지 않았습니다. .env 파일을 확인해 주세요.")

        response = client.chat.completions.create(
            model=MODEL_NAME,
            messages=[
                {"role": "system", "content": req.system_prompt},
                {"role": "user", "content": req.prompt}
            ],
            temperature=0.4,
            max_tokens=req.max_tokens
        )
        return {"text": response.choices[0].message.content.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/", response_class=HTMLResponse)
def serve_ui():
    return """<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Enterprise AI Workspace</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Pretendard-Regular:wght@400;500;600;700&display=swap');

:root{
  --ink:#202124;
  --ink-soft:#5f6368;
  --paper:#FFFFFF;
  --paper-card:#FFFFFF;
  --line:#E8EAED;
  --stamp:#1A73E8;
  --stamp-soft:rgba(26,115,232,0.08);
  --text:#202124;
  --muted:#5f6368;
  --gold:#1A73E8;
  --ok:#137333;
  --radius:12px;
}
*{box-sizing:border-box;}
body{
  margin:0;
  background:#F8F9FA;
  color:var(--text);
  font-family:'Pretendard-Regular','Apple SD Gothic Neo',-apple-system,sans-serif;
  font-size:14px;
  line-height:1.6;
}
.app{
  display:flex;
  min-height:100vh;
}

/* ---------- Sidebar (깔끔한 다크/미니멀 톤) ---------- */
.sidebar{
  width:245px;
  flex-shrink:0;
  background:#202124;
  color:#BDC1C6;
  display:flex;
  flex-direction:column;
  padding:24px 16px;
  border-right:1px solid #3c4043;
}
.brand{
  display:flex;
  align-items:center;
  gap:12px;
  padding:4px 6px 24px 6px;
  border-bottom:1px solid #3c4043;
  margin-bottom:16px;
}
.brand-mark{
  width:32px;height:32px;border-radius:8px;
  background:var(--stamp);
  display:flex;align-items:center;justify-content:center;
  font-weight:700;font-size:15px;color:#fff;
  flex-shrink:0;
}
.brand-text{font-size:16px;font-weight:700;color:#E8EAED;letter-spacing:-0.2px;}
.brand-sub{font-size:11px;color:#9aa0a6;margin-top:1px;}

.nav{display:flex;flex-direction:column;gap:6px;}
.nav-item{
  display:flex;align-items:center;gap:12px;
  padding:12px 14px;border-radius:8px;
  cursor:pointer;color:#BDC1C6;
  font-size:13.5px;font-weight:500;
  transition:background .15s ease,color .15s ease;
  border:1px solid transparent;
}
.nav-item svg{width:18px;height:18px;flex-shrink:0;}
.nav-item:hover{background:rgba(255,255,255,0.06);color:#fff;}
.nav-item.active{
  background:rgba(26,115,232,0.15);
  color:#8ab4f8;
  border-color:rgba(26,115,232,0.3);
}
.nav-foot{
  margin-top:auto;
  padding-top:16px;border-top:1px solid #3c4043;
  font-size:11.5px;color:#9aa0a6;
}

/* ---------- Main (화이트톤 캔버스) ---------- */
.main{flex:1;min-width:0;padding:40px 48px;max-width:1040px;}
.page-header{margin-bottom:28px;}
.eyebrow{font-size:11.5px;letter-spacing:0.08em;text-transform:uppercase;color:var(--stamp);font-weight:600;margin-bottom:4px;}
.page-title{font-size:24px;font-weight:700;margin:0 0 6px 0;color:var(--ink);letter-spacing:-0.3px;}
.page-desc{color:var(--muted);font-size:13.5px;}

.card{
  background:var(--paper-card);
  border:1px solid var(--line);
  border-radius:var(--radius);
  padding:28px;
  margin-bottom:20px;
  position:relative;
  box-shadow:0 1px 3px rgba(0,0,0,0.02);
}
.card + .card{margin-top:20px;}

label{display:block;font-size:12.5px;font-weight:600;color:var(--ink);margin-bottom:8px;}
textarea,input[type=text],input[type=date],select{
  width:100%;
  border:1px solid var(--line);
  border-radius:8px;
  padding:11px 14px;
  font-family:inherit;font-size:13.5px;color:var(--text);
  background:#FFFFFF;
  resize:vertical;
  transition:border-color .15s, box-shadow .15s;
}
textarea:focus,input:focus,select:focus{
  outline:none;
  border-color:var(--stamp);
  box-shadow:0 0 0 3px rgba(26,115,232,0.12);
}
.row{display:flex;gap:16px;flex-wrap:wrap;}
.row > *{flex:1;min-width:140px;}
.field{margin-bottom:16px;}

.btn{
  background:var(--stamp);
  color:#fff;
  border:none;border-radius:8px;
  padding:10px 20px;
  font-size:13.5px;font-weight:600;
  cursor:pointer;
  display:inline-flex;align-items:center;gap:8px;
  transition:background .15s ease, transform .05s ease;
  box-shadow:0 1px 2px rgba(26,115,232,0.2);
}
.btn:hover{background:#1557b0;}
.btn:active{transform:scale(0.99);}
.btn:disabled{opacity:0.6;cursor:not-allowed;}
.btn.secondary{background:transparent;color:var(--ink-soft);border:1px solid var(--line);box-shadow:none;}
.btn.secondary:hover{background:#F1F3F4;color:var(--ink);}
.btn.small{padding:6px 14px;font-size:12.5px;}

.spinner{
  width:14px;height:14px;border-radius:50%;
  border:2px solid rgba(255,255,255,0.35);
  border-top-color:#fff;
  animation:spin .7s linear infinite;
}
@keyframes spin{to{transform:rotate(360deg);}}

.result{
  margin-top:20px;
  border-top:1px solid var(--line);
  padding-top:20px;
  white-space:pre-wrap;
  font-size:13.5px;
  line-height:1.75;
  position:relative;
}
.result-empty{color:var(--muted);font-size:13px;}

.stamp-badge{
  position:absolute;
  top:18px;right:22px;
  width:56px;height:56px;
  border:2px solid var(--stamp);
  color:var(--stamp);
  border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  flex-direction:column;
  font-weight:700;font-size:11px;
  transform:scale(0);
  opacity:0;
  pointer-events:none;
  background:rgba(26,115,232,0.03);
}
.stamp-badge.show{
  animation:stampIn .4s cubic-bezier(.34,1.56,.64,1) forwards;
}
@keyframes stampIn{
  0%{transform:scale(2);opacity:0;}
  60%{transform:scale(0.92);opacity:1;}
  100%{transform:scale(1);opacity:1;}
}
@media (prefers-reduced-motion: reduce){
  .stamp-badge.show{animation:none;transform:scale(1);opacity:1;}
}

/* idea cards */
.idea-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px;margin-top:16px;}
.idea-card{
  border:1px solid var(--line);border-radius:10px;
  padding:16px;background:#F8F9FA;
}
.idea-num{
  color:var(--stamp);font-weight:700;font-size:11.5px;letter-spacing:0.05em;
}
.idea-title{font-weight:600;font-size:14px;margin:6px 0 6px 0;color:var(--ink);}
.idea-desc{font-size:13px;color:var(--muted);line-height:1.55;}

/* room booking */
.room-legend{display:flex;gap:16px;margin-bottom:14px;flex-wrap:wrap;}
.legend-item{display:flex;align-items:center;gap:6px;font-size:12.5px;color:var(--muted);}
.legend-dot{width:10px;height:10px;border-radius:3px;}
.legend-dot.free{background:#F1F3F4;border:1px solid var(--line);}
.legend-dot.busy{background:#dadce0;color:var(--muted);}
.legend-dot.sel{background:var(--stamp);}

.grid-wrap{overflow-x:auto;}
table.booking{border-collapse:collapse;width:100%;min-width:600px;}
table.booking th,table.booking td{
  border:1px solid var(--line);
  text-align:center;
  font-size:12.5px;
  padding:0;
}
table.booking th{
  background:#F8F9FA;
  color:var(--ink);
  font-weight:600;
  padding:10px 6px;
}
table.booking td.time{background:#F8F9FA;color:var(--muted);font-weight:500;padding:10px 8px;white-space:nowrap;}
.slot{
  height:38px;cursor:pointer;
  transition:background .12s ease;
}
.slot.free:hover{background:var(--stamp-soft);}
.slot.busy{background:#F1F3F4;color:#80868b;font-size:11.5px;cursor:default;font-weight:500;}
.slot.selected{background:var(--stamp);color:#fff;}

.book-form{
  margin-top:16px;padding:18px;
  border:1px solid var(--stamp);
  border-radius:10px;
  background:var(--stamp-soft);
}
.book-form-title{font-weight:600;font-size:13.5px;margin-bottom:12px;color:var(--ink);}

.sync-row{display:flex;gap:14px;margin-top:16px;flex-wrap:wrap;}
.sync-chip{
  display:flex;align-items:center;gap:8px;
  border:1px solid var(--line);border-radius:24px;
  padding:8px 16px;font-size:13px;background:#F8F9FA;
}
.sync-dot{width:8px;height:8px;border-radius:50%;background:var(--ok);}
.toggle{
  width:36px;height:20px;border-radius:10px;background:#dadce0;
  position:relative;cursor:pointer;flex-shrink:0;transition:background .15s;
}
.toggle::after{
  content:'';position:absolute;top:2px;left:2px;
  width:16px;height:16px;border-radius:50%;background:#fff;
  transition:transform .15s;
  box-shadow:0 1px 2px rgba(0,0,0,0.2);
}
.toggle.on{background:var(--stamp);}
.toggle.on::after{transform:translateX(16px);}

details.arch{margin-top:16px;font-size:13px;color:var(--ink-soft);}
details.arch summary{cursor:pointer;font-weight:600;color:var(--ink);padding:4px 0;}
details.arch .arch-body{margin-top:8px;line-height:1.8;color:var(--muted);}
details.arch code{background:#F1F3F4;padding:2px 6px;border-radius:4px;font-size:12px;color:var(--ink);}

.today-list{margin-top:20px;}
.today-list-title{font-size:13px;font-weight:600;color:var(--ink);margin-bottom:10px;}
.booking-row{
  display:flex;justify-content:space-between;align-items:center;
  padding:10px 12px;border-bottom:1px solid var(--line);font-size:13px;
}
.booking-row:last-child{border-bottom:none;}
.booking-tag{color:var(--muted);font-size:12px;}

@media (max-width:800px){
  .app{flex-direction:column;}
  .sidebar{width:100%;flex-direction:row;overflow-x:auto;padding:12px;align-items:center;border-right:none;border-bottom:1px solid #3c4043;}
  .brand{border:none;margin:0 12px 0 0;padding:0;}
  .nav{flex-direction:row;}
  .nav-foot{display:none;}
  .main{padding:24px;}
}
</style>
</head>
<body>
<div class="app">

  <aside class="sidebar">
    <div class="brand">
      <div class="brand-mark">AI</div>
      <div>
        <div class="brand-text">Enterprise AI</div>
        <div class="brand-sub">사내 지능형 워크스페이스</div>
      </div>
    </div>
    <nav class="nav">
      <div class="nav-item active" data-page="summary">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 3h8l5 5v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M15 3v5h5"/><path d="M9 13h6M9 16h6M9 10h2"/></svg>
        문서 요약
      </div>
      <div class="nav-item" data-page="idea">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 18h6M10 21h4"/><path d="M12 3a6 6 0 0 0-3.5 10.9c.5.4.8 1 .8 1.6h5.4c0-.6.3-1.2.8-1.6A6 6 0 0 0 12 3z"/></svg>
        아이디어 도출
      </div>
      <div class="nav-item" data-page="minutes">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16v16H4z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>
        회의록 작성
      </div>
      <div class="nav-item" data-page="room">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="16" rx="1.5"/><path d="M3 9h18M8 3v4M16 3v4"/></svg>
        회의실 예약
      </div>
    </nav>
    <div class="nav-foot">Workspace v1.0</div>
  </aside>

  <main class="main">

    <!-- ===== 문서 요약 ===== -->
    <section id="page-summary">
      <div class="page-header">
        <div class="eyebrow">Document Intelligence</div>
        <div class="page-title">문서 요약</div>
        <div class="page-desc">보고서, 이메일, 문서 내용을 붙여넣으면 핵심 내용을 신속하게 요약해 드립니다.</div>
      </div>
      <div class="card">
        <div class="field">
          <label for="sum-input">요약 대상 문서</label>
          <textarea id="sum-input" rows="9" placeholder="여기에 문서 내용을 입력하거나 붙여넣으세요."></textarea>
        </div>
        <div class="row">
          <div class="field">
            <label for="sum-length">요약 분량</label>
            <select id="sum-length">
              <option value="한 문단, 3문장 이내로 짧게">간단히 (3문장)</option>
              <option value="핵심 불릿 5개 내외로" selected>표준 (불릿 5개)</option>
              <option value="배경, 핵심 내용, 시사점을 구분해 상세하게">상세 분석</option>
            </select>
          </div>
          <div class="field">
            <label for="sum-style">출력 형식</label>
            <select id="sum-style">
              <option value="개조식(불릿)">개조식 (불릿포인트)</option>
              <option value="서술형 문단">서술형 문단</option>
            </select>
          </div>
        </div>
        <button class="btn" id="sum-btn" onclick="runSummary()">
          <span id="sum-btn-label">요약 생성</span>
        </button>
        <div class="result" id="sum-result">
          <div class="stamp-badge" id="sum-stamp">완료</div>
          <div class="result-empty">생성된 요약 결과가 여기에 표시됩니다.</div>
        </div>
      </div>
    </section>

    <!-- ===== 아이디어 도출 ===== -->
    <section id="page-idea" style="display:none;">
      <div class="page-header">
        <div class="eyebrow">Brainstorming</div>
        <div class="page-title">아이디어 도출</div>
        <div class="page-desc">해결하고 싶은 과제나 주제를 입력하면 AI가 실행 가능한 아이디어를 제안합니다.</div>
      </div>
      <div class="card">
        <div class="field">
          <label for="idea-topic">주제 / 해결 과제</label>
          <textarea id="idea-topic" rows="3" placeholder="예: 신규 프로젝트 온보딩 효율성 제고 방안"></textarea>
        </div>
        <div class="row">
          <div class="field">
            <label for="idea-count">추천 개수</label>
            <select id="idea-count">
              <option value="3">3개</option>
              <option value="5" selected>5개</option>
              <option value="8">8개</option>
            </select>
          </div>
          <div class="field">
            <label for="idea-tone">접근 성향</label>
            <select id="idea-tone">
              <option value="현실적으로 바로 실행 가능한">현실적・즉시 실행형</option>
              <option value="다소 과감하고 도전적인">과감・도전형</option>
              <option value="비용을 최소화하는">저비용 고효율</option>
            </select>
          </div>
        </div>
        <button class="btn" id="idea-btn" onclick="runIdea()">
          <span id="idea-btn-label">아이디어 도출</span>
        </button>
        <div class="result" id="idea-result">
          <div class="stamp-badge" id="idea-stamp">완료</div>
          <div class="result-empty">제안된 아이디어가 여기에 표시됩니다.</div>
        </div>
      </div>
    </section>

    <!-- ===== 회의록 작성 ===== -->
    <section id="page-minutes" style="display:none;">
      <div class="page-header">
        <div class="eyebrow">Meeting Minutes</div>
        <div class="page-title">회의록 작성</div>
        <div class="page-desc">두서없는 회의 메모나 녹취록을 체계적인 비즈니스 회의록으로 변환합니다.</div>
      </div>
      <div class="card">
        <div class="row">
          <div class="field">
            <label for="min-title">회의 안건 / 제목</label>
            <input type="text" id="min-title" placeholder="예: 3분기 마케팅 전략 수립 회의">
          </div>
          <div class="field">
            <label for="min-date">회의 일시</label>
            <input type="date" id="min-date">
          </div>
        </div>
        <div class="field">
          <label for="min-attend">참석자</label>
          <input type="text" id="min-attend" placeholder="예: 김민준 팀장, 이서연 매니저">
        </div>
        <div class="field">
          <label for="min-raw">회의 메모 / 대화 내용</label>
          <textarea id="min-raw" rows="9" placeholder="회의 중 작성한 메모나 대화 내용을 원문 그대로 입력하세요."></textarea>
        </div>
        <button class="btn" id="min-btn" onclick="runMinutes()">
          <span id="min-btn-label">회의록 정리</span>
        </button>
        <div class="result" id="min-result">
          <div class="stamp-badge" id="min-stamp">완료</div>
          <div class="result-empty">정리된 회의록이 여기에 표시됩니다.</div>
        </div>
      </div>
    </section>

    <!-- ===== 회의실 예약 ===== -->
    <section id="page-room" style="display:none;">
      <div class="page-header">
        <div class="eyebrow">Resource Booking</div>
        <div class="page-title">회의실 예약</div>
        <div class="page-desc">날짜별 회의실 현황을 확인하고 빈 시간대를 선택하여 예약할 수 있습니다.</div>
      </div>

      <div class="card">
        <div class="row" style="align-items:flex-end;">
          <div class="field" style="max-width:220px;">
            <label for="room-date">예약 날짜</label>
            <input type="date" id="room-date" onchange="renderGrid()">
          </div>
          <div class="field" style="flex:2;">
            <div class="room-legend">
              <div class="legend-item"><span class="legend-dot free"></span>예약 가능</div>
              <div class="legend-item"><span class="legend-dot busy"></span>예약 완료</div>
              <div class="legend-item"><span class="legend-dot sel"></span>선택됨</div>
            </div>
          </div>
        </div>

        <div class="grid-wrap">
          <table class="booking" id="booking-table"></table>
        </div>

        <div id="book-form-wrap"></div>

        <div class="today-list">
          <div class="today-list-title">금일 예약 현황 요약</div>
          <div id="today-list-body"></div>
        </div>
      </div>

      <div class="card">
        <div class="page-desc" style="margin-bottom:4px;"><strong style="color:var(--ink);">캘린더 연동 프로토콜</strong></div>
        <div class="sync-row">
          <div class="sync-chip"><span class="sync-dot"></span>Google Workspace &nbsp;<div class="toggle on" onclick="this.classList.toggle('on')"></div></div>
          <div class="sync-chip"><span class="sync-dot"></span>Microsoft 365 &nbsp;<div class="toggle" onclick="this.classList.toggle('on')"></div></div>
        </div>
        <details class="arch">
          <summary>시스템 연동 아키텍처 상세 보기</summary>
          <div class="arch-body">
            1) 관리자 권한으로 <code>OAuth 2.0</code> 인증을 거쳐 각 그룹웨어 리소스 캘린더 계정과 연동됩니다.<br>
            2) 실시간 타임테이블 조회는 Google <code>freebusy.query</code> 및 MS Graph API 기반으로 동기화됩니다.<br>
            3) 예약 확정 시 각 플랫폼의 캘린더 이벤트가 자동 생성되며 참석자에게 푸시 알림이 발송됩니다.
          </div>
        </details>
      </div>
    </section>

  </main>
</div>

<script>
async function callBackend(system, prompt, maxTokens){
  const response = await fetch("/api/ai", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system_prompt: system, prompt: prompt, max_tokens: maxTokens || 1000 })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || "서버 통신 중 오류가 발생했습니다.");
  return data.text;
}

function setLoading(btnId, labelId, isLoading, loadingText, doneText){
  const btn = document.getElementById(btnId);
  const label = document.getElementById(labelId);
  btn.disabled = isLoading;
  label.innerHTML = isLoading ? '<span class="spinner"></span> ' + loadingText : doneText;
}

function fireStamp(id){
  const el = document.getElementById(id);
  el.classList.remove('show');
  void el.offsetWidth;
  el.classList.add('show');
}

/* Navigation - 탭 전환 로직 수정 반영 */
const pages = ['summary','idea','minutes','room'];
document.querySelectorAll('.nav-item').forEach(item=>{
  item.addEventListener('click', ()=>{
    document.querySelectorAll('.nav-item').forEach(i=>i.classList.remove('active'));
    item.classList.add('active');
    const target = item.dataset.page;
    pages.forEach(p=>{
      const sec = document.getElementById('page-'+p);
      if(sec) sec.style.display = (p === target) ? 'block' : 'none';
    });
  });
});

/* 문서 요약 */
async function runSummary(){
  const input = document.getElementById('sum-input').value.trim();
  const resultBox = document.getElementById('sum-result');
  if(!input){
    resultBox.innerHTML = '<div class="stamp-badge" id="sum-stamp">완료</div><div class="result-empty">요약할 문서 내용을 입력해 주세요.</div>';
    return;
  }
  const length = document.getElementById('sum-length').value;
  const style = document.getElementById('sum-style').value;
  setLoading('sum-btn','sum-btn-label',true,'분석 중...','요약 생성');
  resultBox.innerHTML = '<div class="stamp-badge" id="sum-stamp">완료</div><div class="result-empty">AI가 문서를 분석하고 있습니다...</div>';
  try{
    const system = "당신은 전문 문서 요약 어시스턴트입니다. 군더더기 없이 전문적인 비즈니스 톤으로, " + length + ", " + style + " 형식으로 작성하세요. 인사말 없이 바로 요약문만 출력하세요.";
    const text = await callBackend(system, input, 900);
    resultBox.innerHTML = '<div class="stamp-badge" id="sum-stamp">완료</div>' + escapeHtml(text);
    fireStamp('sum-stamp');
  }catch(e){
    resultBox.innerHTML = '<div class="stamp-badge" id="sum-stamp">완료</div><div class="result-empty">요약 실패: ' + e.message + '</div>';
  }finally{
    setLoading('sum-btn','sum-btn-label',false,'','요약 생성');
  }
}

/* 아이디어 도출 */
async function runIdea(){
  const topic = document.getElementById('idea-topic').value.trim();
  const resultBox = document.getElementById('idea-result');
  if(!topic){
    resultBox.innerHTML = '<div class="stamp-badge" id="idea-stamp">완료</div><div class="result-empty">주제 또는 과제를 입력해 주세요.</div>';
    return;
  }
  const count = document.getElementById('idea-count').value;
  const tone = document.getElementById('idea-tone').value;
  setLoading('idea-btn','idea-btn-label',true,'구상 중...','아이디어 도출');
  resultBox.innerHTML = '<div class="stamp-badge" id="idea-stamp">완료</div><div class="result-empty">아이디어를 도출하고 있습니다...</div>';
  try{
    const system = "당신은 기획 전문가입니다. 주어진 주제에 대해 " + tone + " 아이디어를 정확히 " + count + "개 제안하세요. " +
      "반드시 다른 설명 없이 JSON 배열 형식으로만 응답하세요: " +
      '[{"title":"아이디어 제목 (15자 이내)","description":"구체적인 설명 1~2문장"}]';
    const raw = await callBackend(system, topic, 900);
    const clean = raw.replace(/```json|```/g,'').trim();
    const ideas = JSON.parse(clean);
    let html = '<div class="stamp-badge" id="idea-stamp">완료</div><div class="idea-grid">';
    ideas.forEach((it,i)=>{
      html += '<div class="idea-card"><div class="idea-num">IDEA ' + String(i+1).padStart(2,'0') + '</div>' +
        '<div class="idea-title">' + escapeHtml(it.title||'') + '</div>' +
        '<div class="idea-desc">' + escapeHtml(it.description||'') + '</div></div>';
    });
    html += '</div>';
    resultBox.innerHTML = html;
    fireStamp('idea-stamp');
  }catch(e){
    resultBox.innerHTML = '<div class="stamp-badge" id="idea-stamp">완료</div><div class="result-empty">도출 실패: ' + e.message + '</div>';
  }finally{
    setLoading('idea-btn','idea-btn-label',false,'','아이디어 도출');
  }
}

/* 회의록 작성 */
async function runMinutes(){
  const raw = document.getElementById('min-raw').value.trim();
  const resultBox = document.getElementById('min-result');
  if(!raw){
    resultBox.innerHTML = '<div class="stamp-badge" id="min-stamp">완료</div><div class="result-empty">회의 메모를 입력해 주세요.</div>';
    return;
  }
  const title = document.getElementById('min-title').value.trim() || '일반 회의';
  const date = document.getElementById('min-date').value || '날짜 미지정';
  const attend = document.getElementById('min-attend').value.trim() || '참석자 미지정';
  setLoading('min-btn','min-btn-label',true,'작성 중...','회의록 정리');
  resultBox.innerHTML = '<div class="stamp-badge" id="min-stamp">완료</div><div class="result-empty">회의록을 구조화하고 있습니다...</div>';
  try{
    const system = "당신은 전문 비즈니스 서기입니다. 아래 메모를 정식 회의록 양식으로 정리하세요. " +
      "구성: [안건 및 제목] / [일시] / [참석자] / [주요 논의 사항](불릿) / [결정 사항](불릿) / [향후 실행 과제(Action Items)]. " +
      "제목: " + title + ", 일시: " + date + ", 참석자: " + attend + ". 인사말 없이 본문만 출력하세요.";
    const text = await callBackend(system, raw, 1000);
    resultBox.innerHTML = '<div class="stamp-badge" id="min-stamp">완료</div>' + escapeHtml(text);
    fireStamp('min-stamp');
  }catch(e){
    resultBox.innerHTML = '<div class="stamp-badge" id="min-stamp">완료</div><div class="result-empty">작성 실패: ' + e.message + '</div>';
  }finally{
    setLoading('min-btn','min-btn-label',false,'','회의록 정리');
  }
}

function escapeHtml(str){
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

/* 회의실 예약 목업 */
const rooms = [
  {id:'A', name:'회의실 A', floor:'3F · 4인'},
  {id:'B', name:'회의실 B', floor:'3F · 8인'},
  {id:'C', name:'회의실 C', floor:'5F · 12인'},
  {id:'D', name:'임원 회의실', floor:'7F · 6인'},
];
const hours = [9,10,11,12,13,14,15,16,17];
let bookings = {};
let selectedCell = null;

function todayStr(){
  return new Date().toISOString().slice(0,10);
}
const roomDateInput = document.getElementById('room-date');
if(roomDateInput) roomDateInput.value = todayStr();

function cellKey(date, roomId, hour){ return date+'_'+roomId+'_'+hour; }

function renderGrid(){
  const dateEl = document.getElementById('room-date');
  const date = dateEl ? dateEl.value || todayStr() : todayStr();
  const table = document.getElementById('booking-table');
  if(!table) return;
  
  let html = '<thead><tr><th>시간</th>';
  rooms.forEach(r=>{ html += '<th>' + r.name + '<br><span style="font-weight:400;font-size:11px;color:var(--muted);">' + r.floor + '</span></th>'; });
  html += '</tr></thead><tbody>';
  hours.forEach(h=>{
    html += '<tr><td class="time">' + h + ':00</td>';
    rooms.forEach(r=>{
      const key = cellKey(date, r.id, h);
      const b = bookings[key];
      const isSel = selectedCell === key;
      if(b){
        html += '<td class="slot busy" title="' + escapeHtml(b.title) + ' (' + escapeHtml(b.owner) + ')">' + escapeHtml(b.title.slice(0,6)) + '</td>';
      }else{
        html += '<td class="slot free' + (isSel?' selected':'') + '" onclick="selectCell(\'' + date + '\',\'' + r.id + '\',' + h + ')"></td>';
      }
    });
    html += '</tr>';
  });
  html += '</tbody>';
  table.innerHTML = html;
  renderTodayList(date);
  renderBookForm(date);
}

function selectCell(date, roomId, hour){
  selectedCell = cellKey(date, roomId, hour);
  renderGrid();
}

function renderBookForm(date){
  const wrap = document.getElementById('book-form-wrap');
  if(!wrap) return;
  if(!selectedCell){ wrap.innerHTML = ''; return; }
  const [d, roomId, hour] = selectedCell.split('_');
  const room = rooms.find(r=>r.id===roomId);
  wrap.innerHTML =
    '<div class="book-form">' +
      '<div class="book-form-title">' + room.name + ' · ' + d + ' ' + hour + ':00 ~ ' + (Number(hour)+1) + ':00 예약 등록</div>' +
      '<div class="row">' +
        '<div class="field"><label>예약 안건 / 회의명</label><input type="text" id="bf-title" placeholder="예: 스프린트 싱크 미팅"></div>' +
        '<div class="field"><label>예약자 성명</label><input type="text" id="bf-owner" placeholder="예: 김민준"></div>' +
      '</div>' +
      '<button class="btn small" onclick="confirmBooking()">예약 확정</button> ' +
      '<button class="btn small secondary" onclick="cancelSelect()">취소</button>' +
    '</div>';
}

function confirmBooking(){
  const titleInput = document.getElementById('bf-title');
  const ownerInput = document.getElementById('bf-owner');
  const title = titleInput ? titleInput.value.trim() || '지정 미팅' : '지정 미팅';
  const owner = ownerInput ? ownerInput.value.trim() || '임직원' : '임직원';
  bookings[selectedCell] = {title, owner};
  selectedCell = null;
  renderGrid();
}

function cancelSelect(){
  selectedCell = null;
  renderGrid();
}

function renderTodayList(date){
  const body = document.getElementById('today-list-body');
  if(!body) return;
  const entries = Object.keys(bookings)
    .filter(k=>k.startsWith(date+'_'))
    .map(k=>{
      const [d, roomId, hour] = k.split('_');
      const room = rooms.find(r=>r.id===roomId);
      return {hour:Number(hour), room:room.name, ...bookings[k], key:k};
    })
    .sort((a,b)=>a.hour-b.hour);
  if(entries.length===0){
    body.innerHTML = '<div class="result-empty">예약된 회의실 일정이 없습니다.</div>';
    return;
  }
  body.innerHTML = entries.map(e=>
    '<div class="booking-row"><span>' + e.hour + ':00 · ' + e.room + ' · ' + escapeHtml(e.title) + ' <span class="booking-tag">(' + escapeHtml(e.owner) + ')</span></span>' +
    '<button class="btn small secondary" onclick="removeBooking(\'' + e.key + '\')">취소</button></div>'
  ).join('');
}

function removeBooking(key){
  delete bookings[key];
  renderGrid();
}

renderGrid();
</script>
</body>
</html>
"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)