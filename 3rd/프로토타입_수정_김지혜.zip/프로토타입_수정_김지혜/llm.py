import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage

load_dotenv()

def get_llm(model_name: str = "gpt-4o-mini", temperature: float = 0.3):
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY가 설정되지 않았습니다.")
    return ChatOpenAI(model=model_name, temperature=temperature, openai_api_key=api_key)

def run_agent_task(task_type: str, user_input: str, context: str = "") -> str:
    """
    4가지 업무 시나리오(문서작성, 아이디어도출, 회의록작성, 회의실예약)에 따른 맞춤형 실행 함수
    """
    llm = get_llm(temperature=0.4)
    
    system_prompts = {
        "문서 작성": "당신은 전문적인 비즈니스 문서 작성 에이전트입니다. 보고서, 기획서, 이메일 초안 등을 격식 있고 깔끔하게 작성해 주세요.",
        "아이디어 도출": "당신은 창의적인 기획 및 전략 컨설턴트입니다. 비즈니스 성장에 도움이 되는 혁신적이고 실현 가능한 아이디어를 다각도로 제안해 주세요.",
        "회의록 작성": "당신은 탁월한 요약 능력을 갖춘 비서입니다. 제공된 회의 녹취록이나 메모를 바탕으로 '핵심 안건, 주요 논의 내용, 결정 사항, 향후 액션 아이템(Action Item)'으로 깔끔하게 정리해 주세요.",
        "회의실 예약": "당신은 사내 자원 관리 에이전트입니다. 회의실 예약 가능 여부 확인 및 일정 조율을 도와주는 친절하고 정확한 안내를 제공합니다."
    }
    
    sys_prompt = system_prompts.get(task_type, "당신은 유능한 기업용 AI 어시스턴트입니다.")
    
    messages = [SystemMessage(content=sys_prompt)]
    
    if context:
        messages.append(HumanMessage(content=f"[참고 사내 문서/데이터]:\n{context}\n\n[사용자 요청]: {user_input}"))
    else:
        messages.append(HumanMessage(content=user_input))
        
    response = llm.invoke(messages)
    return response.content