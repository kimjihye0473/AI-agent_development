import os
import json
import logging
from typing import List, Dict

from dotenv import load_dotenv
from langchain_anthropic import ChatAnthropic
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()  # .env 파일에 있는 ANTHROPIC_API_KEY 등을 환경변수로 로드

logger = logging.getLogger("llm")

MODEL = os.environ.get("CLAUDE_MODEL", "claude-sonnet-4-6")

_llm = ChatAnthropic(
    model=MODEL,
    max_tokens=1000,
    api_key=os.environ.get("ANTHROPIC_API_KEY"),
)
_parser = StrOutputParser()


class LLMError(Exception):
    """LLM 호출/파싱 실패 시 발생시키는 공통 예외."""
    pass


def _invoke(system: str, user_content: str, max_tokens: int = 1000) -> str:
    """system/human 메시지로 체인을 구성해 실행하고 텍스트를 반환한다."""
    prompt = ChatPromptTemplate.from_messages([
        ("system", system),
        ("human", "{input}"),
    ])
    chain = prompt | _llm.bind(max_tokens=max_tokens) | _parser
    try:
        text = chain.invoke({"input": user_content})
    except Exception as e:
        # 상세 원인(API 키/네트워크/설정값 등)은 서버 로그에만 남기고,
        # 사용자(클라이언트)에게는 내부 구현이 드러나지 않는 일반 안내 문구만 전달한다.
        logger.exception("Claude(LangChain) 호출 실패")
        raise LLMError("LLM 호출 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.") from e

    if not text or not text.strip():
        raise LLMError("LLM이 빈 응답을 반환했습니다.")
    return text.strip()


def _try_parse_json(raw: str):
    """```json 코드펜스 등을 제거하고 JSON 파싱을 시도한다. 실패 시 None."""
    cleaned = raw.replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        return None


def _invoke_json(system: str, user_content: str, max_tokens: int = 1000):
    """JSON만 반환하도록 강제한 프롬프트의 응답을 파싱해 반환한다.

    LLM이 지시를 정확히 지키지 않아(설명 덧붙임, 트레일링 콤마 등) 1차 파싱이
    실패하는 경우, 형식을 교정해 다시 응답하도록 한 번만 재시도한다.
    """
    raw = _invoke(system, user_content, max_tokens)
    parsed = _try_parse_json(raw)
    if parsed is not None:
        return parsed

    logger.warning("JSON 파싱 실패, 형식 교정 재시도 진행: %s", raw)

    retry_system = (
        system
        + "\n\n[중요] 방금 응답이 유효한 JSON 형식이 아니었습니다. "
        "설명, 코드펜스, 인사말 없이 순수한 JSON만 다시 출력하세요."
    )
    retry_raw = _invoke(retry_system, user_content, max_tokens)
    parsed = _try_parse_json(retry_raw)
    if parsed is not None:
        return parsed

    logger.error("JSON 파싱 재시도도 실패: %s", retry_raw)
    raise LLMError("LLM 응답을 JSON으로 해석하지 못했습니다. 다시 시도해주세요.")


# ---------------------------------------------------------------------------
# 1) 문서 요약
# ---------------------------------------------------------------------------
def summarize_document(text: str, length: str = "보통", style: str = "개조식") -> str:
    length_map = {
        "간단히": "한 문단, 3문장 이내로 짧게",
        "보통": "핵심 불릿 5개 내외로",
        "상세히": "배경, 핵심 내용, 시사점을 구분해 상세하게",
    }
    system = (
        "당신은 한국 기업의 사내 문서 요약 담당자입니다. 군더더기 없는 업무용 한국어로, "
        f"{length_map.get(length, length)}, {style}으로 작성하세요. "
        "서두 인사말이나 부연 설명 없이 바로 요약 내용만 출력하세요."
    )
    return _invoke(system, text, max_tokens=900)


# ---------------------------------------------------------------------------
# 2) 아이디어 도출
# ---------------------------------------------------------------------------
def generate_ideas(topic: str, count: int = 5, tone: str = "현실적으로 바로 실행 가능한") -> List[Dict]:
    system = (
        "당신은 한국 기업의 사내 기획 담당자입니다. 주어진 주제에 대해 "
        f"{tone} 아이디어를 정확히 {count}개 제안하세요. "
        "반드시 다른 텍스트 없이 아래 JSON 배열 형식으로만 응답하세요: "
        '[{"title": "아이디어 제목(15자 내외)", "description": "한 두 문장 설명"}]'
    )
    ideas = _invoke_json(system, topic, max_tokens=900)
    if not isinstance(ideas, list) or not all(
        isinstance(item, dict) and "title" in item and "description" in item
        for item in ideas
    ):
        raise LLMError("아이디어 응답 형식이 올바르지 않습니다. 다시 시도해주세요.")
    return ideas


# ---------------------------------------------------------------------------
# 3) 회의록 작성
# ---------------------------------------------------------------------------
def generate_minutes(title: str, date: str, attendees: str, raw_notes: str) -> str:
    system = (
        "당신은 한국 기업의 사내 서기입니다. 아래 메모를 정식 회의록 형식으로 정리하세요. "
        "형식은 반드시 다음 순서를 따르세요: [회의 제목] / [일시] / [참석자] / [안건] / "
        "[논의 내용](불릿) / [결정 사항](불릿) / [Action Item](담당자와 함께 불릿). "
        f"회의 제목: {title or '(제목 미입력)'}, 일시: {date or '(일시 미입력)'}, "
        f"참석자: {attendees or '(참석자 미입력)'}. "
        "부연 설명이나 인사말 없이 회의록 본문만 출력하세요."
    )
    return _invoke(system, raw_notes, max_tokens=1000)


# ---------------------------------------------------------------------------
# 4) RAG 기반 질의응답 (rag_module.py에서 검색한 문서 조각을 근거로 답변)
# ---------------------------------------------------------------------------
def answer_with_context(query: str, context_chunks: List[str]) -> str:
    context_block = "\n\n---\n\n".join(
        f"[문서 조각 {i+1}]\n{chunk}" for i, chunk in enumerate(context_chunks)
    ) or "(관련 문서를 찾지 못했습니다)"

    system = (
        "당신은 사내 지식베이스를 기반으로 답변하는 어시스턴트입니다. "
        "아래 [문서 조각]에 있는 내용만 근거로 답변하세요. "
        "문서 조각에 없는 내용은 추측하지 말고 '사내 문서에서 관련 내용을 찾지 못했습니다'라고 답하세요. "
        "답변 끝에 어떤 문서 조각을 참고했는지 번호로 표시하세요.\n\n"
        f"{context_block}"
    )
    return _invoke(system, query, max_tokens=800)