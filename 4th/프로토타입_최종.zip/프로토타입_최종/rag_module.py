import uuid
import logging
from typing import List, Dict, Optional

from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document as LCDocument

logger = logging.getLogger("rag_module")

CHUNK_SIZE = 500
CHUNK_OVERLAP = 80
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


class DocumentStore:
    """
    LangChain FAISS 기반 인메모리 문서 저장소.
    add_document / search / delete_document / list_documents 인터페이스는
    app.py 쪽에서 그대로 사용한다.
    """

    def __init__(self):
        self._embeddings = HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL)
        self._splitter = RecursiveCharacterTextSplitter(
            chunk_size=CHUNK_SIZE,
            chunk_overlap=CHUNK_OVERLAP,
            separators=["\n\n", "\n", ". ", " ", ""],
        )
        self._vectorstore: Optional[FAISS] = None
        # doc_id -> {"title": str, "chunk_ids": List[str]}
        self._doc_meta: Dict[str, Dict] = {}

    # -- 색인 -----------------------------------------------------------
    def add_document(self, title: str, text: str, doc_id: Optional[str] = None) -> str:
        """문서를 청크로 나눠 벡터스토어에 추가하고 문서 ID를 반환한다."""
        doc_id = doc_id or str(uuid.uuid4())
        chunk_texts = self._splitter.split_text(text)
        if not chunk_texts:
            self._doc_meta[doc_id] = {"title": title, "chunk_ids": []}
            return doc_id

        lc_docs = [
            LCDocument(
                page_content=chunk,
                metadata={"doc_id": doc_id, "doc_title": title, "chunk_index": i},
            )
            for i, chunk in enumerate(chunk_texts)
        ]

        if self._vectorstore is None:
            self._vectorstore = FAISS.from_documents(lc_docs, self._embeddings)
            chunk_ids = list(self._vectorstore.docstore._dict.keys())
        else:
            chunk_ids = self._vectorstore.add_documents(lc_docs)

        self._doc_meta[doc_id] = {"title": title, "chunk_ids": chunk_ids}
        logger.info("문서 추가됨: %s (%s개 청크)", title, len(chunk_texts))
        return doc_id

    def delete_document(self, doc_id: str) -> bool:
        if doc_id not in self._doc_meta:
            return False
        chunk_ids = self._doc_meta[doc_id]["chunk_ids"]
        if self._vectorstore is not None and chunk_ids:
            self._vectorstore.delete(chunk_ids)
        del self._doc_meta[doc_id]
        return True

    def get_document(self, doc_id: str) -> Optional[Dict]:
        meta = self._doc_meta.get(doc_id)
        if meta is None:
            return None
        return {"doc_id": doc_id, "title": meta["title"], "chunk_count": len(meta["chunk_ids"])}

    def list_documents(self) -> List[Dict]:
        return [
            {"doc_id": doc_id, "title": meta["title"], "chunk_count": len(meta["chunk_ids"])}
            for doc_id, meta in self._doc_meta.items()
        ]

    # -- 검색 -----------------------------------------------------------
    def search(self, query: str, top_k: int = 3) -> List[Dict]:
        """질의와 유사한 청크 top_k개를 반환한다 (score는 거리값, 작을수록 유사)."""
        if self._vectorstore is None:
            return []
        hits = self._vectorstore.similarity_search_with_score(query, k=top_k)
        results = []
        for doc, score in hits:
            results.append({
                "doc_id": doc.metadata.get("doc_id"),
                "doc_title": doc.metadata.get("doc_title"),
                "chunk_id": f"{doc.metadata.get('doc_id')}-{doc.metadata.get('chunk_index')}",
                "text": doc.page_content,
                "score": float(score),
            })
        return results


# 앱 전역에서 공유하는 단일 저장소 인스턴스.
# (프로세스 재시작 시 초기화됨 — 운영 환경에서는 FAISS.save_local()로 영속화하거나
#  pgvector 등 외부 벡터 DB로 교체 필요)
store = DocumentStore()