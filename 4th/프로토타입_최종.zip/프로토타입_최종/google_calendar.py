"""
구글 캘린더(서비스 계정) 연동 모듈.

- 공용 회의실 예약용 구글 캘린더 하나에 서비스 계정으로 접근한다.
- GOOGLE_SERVICE_ACCOUNT_FILE / GOOGLE_CALENDAR_ID 환경변수가 없거나
  인증에 실패하면 '연동 비활성화' 상태로 조용히 폴백한다.
  => 인증정보가 아직 없어도 예약 기능 자체는 정상 동작해야 하므로,
     이 모듈의 모든 공개 함수는 예외를 던지지 않고 실패를 값으로 반환한다.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict
from zoneinfo import ZoneInfo

logger = logging.getLogger("google_calendar")

_SCOPES = ["https://www.googleapis.com/auth/calendar"]

_CALENDAR_ID = os.environ.get("GOOGLE_CALENDAR_ID")
_SERVICE_ACCOUNT_FILE = os.environ.get("GOOGLE_SERVICE_ACCOUNT_FILE")   # 로컬 개발용(선택)
_SERVICE_ACCOUNT_JSON = os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON")   # 시크릿을 문자열로 주입할 때(선택)
_TIMEZONE_NAME = os.environ.get("GOOGLE_CALENDAR_TIMEZONE", "Asia/Seoul")
_TZ = ZoneInfo(_TIMEZONE_NAME)

_service = None
_init_error: Optional[str] = None
_init_attempted = False


def _load_credentials():
    """자격증명을 아래 순서로 시도한다.

    1) GOOGLE_SERVICE_ACCOUNT_JSON — 키 내용을 문자열로 주입한 경우
    2) GOOGLE_SERVICE_ACCOUNT_FILE — 로컬 개발용으로 다운로드한 키 파일
    3) ADC(Application Default Credentials) — 키 파일이 전혀 없는 경우.
       Cloud Run에 연결된 서비스 계정 자격증명을 메타데이터 서버에서
       자동으로 가져온다. 배포 환경(Cloud Run)에서 권장되는 방식이며,
       이 경우 서비스 계정을 구글 캘린더에 '공유'만 해두면 되고
       키 파일/시크릿 관리가 전혀 필요 없다.
    """
    from google.oauth2 import service_account
    import google.auth

    if _SERVICE_ACCOUNT_JSON:
        info = json.loads(_SERVICE_ACCOUNT_JSON)
        return service_account.Credentials.from_service_account_info(info, scopes=_SCOPES)

    if _SERVICE_ACCOUNT_FILE:
        if not os.path.exists(_SERVICE_ACCOUNT_FILE):
            raise FileNotFoundError(f"서비스 계정 키 파일을 찾을 수 없습니다: {_SERVICE_ACCOUNT_FILE}")
        return service_account.Credentials.from_service_account_file(
            _SERVICE_ACCOUNT_FILE, scopes=_SCOPES
        )

    credentials, _ = google.auth.default(scopes=_SCOPES)
    return credentials


def _get_service():
    """구글 캘린더 API 클라이언트를 지연 초기화한다 (최초 1회만 시도)."""
    global _service, _init_error, _init_attempted

    if _service is not None:
        return _service
    if _init_attempted:
        return None
    _init_attempted = True

    if not _CALENDAR_ID:
        _init_error = "GOOGLE_CALENDAR_ID가 설정되지 않았습니다."
        logger.warning("구글 캘린더 연동 비활성화 상태로 동작합니다: %s", _init_error)
        return None

    try:
        from googleapiclient.discovery import build

        credentials = _load_credentials()
        _service = build("calendar", "v3", credentials=credentials, cache_discovery=False)
        logger.info("구글 캘린더 연동 활성화됨 (calendar_id=%s)", _CALENDAR_ID)
        return _service
    except Exception:
        logger.exception("구글 캘린더 클라이언트 초기화 실패")
        _init_error = (
            "구글 캘린더 클라이언트 초기화 중 오류가 발생했습니다. "
            "(서비스 계정 권한/캘린더 공유 설정을 확인하세요)"
        )
        return None


def is_configured() -> bool:
    """프론트엔드의 연동 상태 표시(토글/점)가 실제 상태를 반영하도록 노출하는 상태 조회 함수."""
    return _get_service() is not None


def status() -> Dict:
    configured = is_configured()
    return {
        "configured": configured,
        "calendar_id": _CALENDAR_ID if configured else None,
        "detail": None if configured else (_init_error or "설정되지 않음"),
    }


def _time_range(date: str, hour: int):
    start = datetime.strptime(f"{date} {hour:02d}:00", "%Y-%m-%d %H:%M").replace(tzinfo=_TZ)
    end = start + timedelta(hours=1)
    return start, end


def has_conflict(date: str, hour: int) -> bool:
    """freebusy.query로 이 앱 밖에서(구글 캘린더 UI 등으로) 잡힌 일정과 겹치는지 확인한다.
    연동이 꺼져 있거나 조회에 실패하면 '충돌 없음'으로 간주하고,
    내부 예약 저장소의 자체 중복 체크에 판단을 맡긴다."""
    service = _get_service()
    if service is None:
        return False

    start, end = _time_range(date, hour)
    try:
        result = service.freebusy().query(body={
            "timeMin": start.isoformat(),
            "timeMax": end.isoformat(),
            "items": [{"id": _CALENDAR_ID}],
        }).execute()
        busy = result.get("calendars", {}).get(_CALENDAR_ID, {}).get("busy", [])
        return len(busy) > 0
    except Exception:
        logger.exception("freebusy.query 호출 실패")
        return False


def create_event(date: str, hour: int, title: str, owner: str, room_name: str) -> Optional[Dict]:
    """예약 확정 시 구글 캘린더에 실제 이벤트를 생성한다.
    연동 미설정/실패 시 None을 반환하며, 이 경우에도 앱 내부 예약 저장은 그대로 유지된다
    (구글 캘린더 동기화는 부가 기능이지 예약의 전제조건이 아니다)."""
    service = _get_service()
    if service is None:
        return None

    start, end = _time_range(date, hour)
    body = {
        "summary": f"[{room_name}] {title}",
        "description": f"예약자: {owner}\n(사내 인트라AI 회의실 예약 시스템에서 자동 생성됨)",
        "start": {"dateTime": start.isoformat(), "timeZone": _TIMEZONE_NAME},
        "end": {"dateTime": end.isoformat(), "timeZone": _TIMEZONE_NAME},
    }
    try:
        created = service.events().insert(calendarId=_CALENDAR_ID, body=body).execute()
        return {"event_id": created.get("id"), "html_link": created.get("htmlLink")}
    except Exception:
        logger.exception("구글 캘린더 이벤트 생성 실패")
        return None


def delete_event(event_id: str) -> bool:
    service = _get_service()
    if service is None or not event_id:
        return False
    try:
        service.events().delete(calendarId=_CALENDAR_ID, eventId=event_id).execute()
        return True
    except Exception:
        logger.exception("구글 캘린더 이벤트 삭제 실패")
        return False