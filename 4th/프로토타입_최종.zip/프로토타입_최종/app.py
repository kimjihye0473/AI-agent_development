import logging
from datetime import date as date_type
from typing import List, Optional, Dict

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

import llm
import rag_module
import google_calendar

load_dotenv()  # .env 파일에 있는 ANTHROPIC_API_KEY 등을 환경변수로 로드

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("app")

app = FastAPI(title="인트라AI 백엔드", version="0.1.0")

# 개발 단계에서는 전체 허용, 운영 배포 시 사내 도메인으로 좁혀야 한다.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    """예상하지 못한 예외는 상세 내용을 로그로만 남기고,
    클라이언트에는 내부 구현이 드러나지 않는 일반 오류만 응답한다."""
    logger.exception("처리되지 않은 예외 발생: %s %s", request.method, request.url.path)
    return JSONResponse(
        status_code=500,
        content={"detail": "서버 내부 오류가 발생했습니다. 잠시 후 다시 시도해주세요."},
    )


def _handle_llm_errors(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except llm.LLMError as e:
        logger.error("LLM 오류: %s", e)
        raise HTTPException(status_code=502, detail=str(e))


# ---------------------------------------------------------------------------
# 1) 문서 요약
# ---------------------------------------------------------------------------
class SummarizeRequest(BaseModel):
    text: str = Field(..., min_length=1)
    length: str = "보통"       # 간단히 | 보통 | 상세히
    style: str = "개조식"


class SummarizeResponse(BaseModel):
    summary: str


@app.post("/api/summarize", response_model=SummarizeResponse)
def summarize(req: SummarizeRequest):
    summary = _handle_llm_errors(llm.summarize_document, req.text, req.length, req.style)
    return SummarizeResponse(summary=summary)


# ---------------------------------------------------------------------------
# 2) 아이디어 도출
# ---------------------------------------------------------------------------
class IdeaRequest(BaseModel):
    topic: str = Field(..., min_length=1)
    count: int = 5
    tone: str = "현실적으로 바로 실행 가능한"


class Idea(BaseModel):
    title: str
    description: str


class IdeaResponse(BaseModel):
    ideas: List[Idea]


@app.post("/api/ideas", response_model=IdeaResponse)
def ideas(req: IdeaRequest):
    raw = _handle_llm_errors(llm.generate_ideas, req.topic, req.count, req.tone)
    return IdeaResponse(ideas=[Idea(**item) for item in raw])


# ---------------------------------------------------------------------------
# 3) 회의록 작성
# ---------------------------------------------------------------------------
class MinutesRequest(BaseModel):
    title: str = ""
    date: str = ""
    attendees: str = ""
    raw_notes: str = Field(..., min_length=1)


class MinutesResponse(BaseModel):
    minutes: str


@app.post("/api/minutes", response_model=MinutesResponse)
def minutes(req: MinutesRequest):
    text = _handle_llm_errors(
        llm.generate_minutes, req.title, req.date, req.attendees, req.raw_notes
    )
    return MinutesResponse(minutes=text)


# ---------------------------------------------------------------------------
# 4) 사내 문서 RAG (업로드 + 검색 기반 질의응답)
# ---------------------------------------------------------------------------
class DocumentUploadRequest(BaseModel):
    title: str
    text: str = Field(..., min_length=1)


class DocumentUploadResponse(BaseModel):
    doc_id: str
    chunk_count: int


@app.post("/api/documents", response_model=DocumentUploadResponse)
def upload_document(req: DocumentUploadRequest):
    doc_id = rag_module.store.add_document(req.title, req.text)
    doc = rag_module.store.get_document(doc_id)
    return DocumentUploadResponse(doc_id=doc_id, chunk_count=doc["chunk_count"])


@app.get("/api/documents")
def list_documents():
    return rag_module.store.list_documents()


@app.delete("/api/documents/{doc_id}")
def delete_document(doc_id: str):
    ok = rag_module.store.delete_document(doc_id)
    if not ok:
        raise HTTPException(status_code=404, detail="문서를 찾을 수 없습니다.")
    return {"deleted": doc_id}


class AskRequest(BaseModel):
    query: str = Field(..., min_length=1)
    top_k: int = 3


class AskResponse(BaseModel):
    answer: str
    sources: List[Dict]


@app.post("/api/ask", response_model=AskResponse)
def ask(req: AskRequest):
    hits = rag_module.store.search(req.query, top_k=req.top_k)
    context_chunks = [h["text"] for h in hits]
    answer = _handle_llm_errors(llm.answer_with_context, req.query, context_chunks)
    return AskResponse(answer=answer, sources=hits)


# ---------------------------------------------------------------------------
# 5) 회의실 예약 (데모용 인메모리 저장소 — 운영 시 DB + 캘린더 API로 교체)
# ---------------------------------------------------------------------------
ROOMS = [
    {"id": "A", "name": "회의실 A", "floor": "3층", "capacity": 4},
    {"id": "B", "name": "회의실 B", "floor": "3층", "capacity": 8},
    {"id": "C", "name": "회의실 C", "floor": "5층", "capacity": 12},
    {"id": "D", "name": "임원 회의실", "floor": "7층", "capacity": 6},
]

# key: (date, room_id, hour) -> {"title": ..., "owner": ...}
_bookings: Dict[str, Dict] = {}


def _booking_key(date: str, room_id: str, hour: int) -> str:
    return f"{date}_{room_id}_{hour}"


@app.get("/api/rooms")
def list_rooms():
    return ROOMS


@app.get("/api/calendar/status")
def calendar_status():
    """프론트엔드의 '캘린더 연동' 토글/상태 점이 실제 연동 여부를 그대로 반영하도록
    제공하는 엔드포인트. 항상 켜져 있는 것처럼 보이던 목업 UI 문제를 해결하기 위함."""
    return google_calendar.status()


class BookingRequest(BaseModel):
    date: str          # "YYYY-MM-DD"
    room_id: str
    hour: int          # 9~17
    title: str
    owner: str


@app.get("/api/bookings")
def list_bookings(date: str):
    return [
        {"key": k, **v}
        for k, v in _bookings.items()
        if k.startswith(f"{date}_")
    ]


@app.post("/api/bookings")
def create_booking(req: BookingRequest):
    room = next((r for r in ROOMS if r["id"] == req.room_id), None)
    if room is None:
        raise HTTPException(status_code=404, detail="존재하지 않는 회의실입니다.")

    key = _booking_key(req.date, req.room_id, req.hour)
    if key in _bookings:
        raise HTTPException(status_code=409, detail="이미 예약된 시간입니다.")

    # 구글 캘린더 연동이 켜져 있는 경우, 이 앱 밖에서(구글 캘린더 UI 등으로)
    # 이미 잡힌 일정과 겹치는지도 함께 확인한다. 연동이 꺼져 있으면 항상 False.
    if google_calendar.has_conflict(req.date, req.hour):
        raise HTTPException(
            status_code=409,
            detail="구글 캘린더 기준으로 이미 다른 일정이 있는 시간입니다.",
        )

    calendar_event = google_calendar.create_event(
        req.date, req.hour, req.title, req.owner, room["name"]
    )

    _bookings[key] = {
        "title": req.title,
        "owner": req.owner,
        "room_id": req.room_id,
        "date": req.date,
        "hour": req.hour,
        "calendar_synced": calendar_event is not None,
        "calendar_event_id": calendar_event["event_id"] if calendar_event else None,
        "calendar_html_link": calendar_event["html_link"] if calendar_event else None,
    }
    return {"key": key, **_bookings[key]}


@app.delete("/api/bookings")
def cancel_booking(date: str, room_id: str, hour: int):
    key = _booking_key(date, room_id, hour)
    if key not in _bookings:
        raise HTTPException(status_code=404, detail="예약을 찾을 수 없습니다.")

    event_id = _bookings[key].get("calendar_event_id")
    if event_id:
        google_calendar.delete_event(event_id)

    del _bookings[key]
    return {"cancelled": key}


@app.get("/health")
def health():
    return {"status": "ok"}