import streamlit as st
from rag_module import RAGSystem

st.set_page_config(
    page_title="기업 AI Assistant",
    page_icon="🤖",
    layout="wide"
)
rag = RAGSystem()

st.title("📄 기업 전용 AI Assistant")
st.write("LLM + RAG 기반 문서 검색 AI")

uploaded_file = st.file_uploader(
    "PDF를 업로드하세요.",
    type=["pdf"]
)
if uploaded_file is not None:

    text = rag.load_pdf(uploaded_file)

    rag.split_text(text)

    rag.create_vector_db()

    st.success("PDF 업로드 완료!")

question = st.text_input(
    "질문을 입력하세요."
)
if st.button("질문하기"):

    if uploaded_file is None:
        st.warning("먼저 PDF를 업로드하세요.")

    elif question == "":
        st.warning("질문을 입력하세요.")

    else:
        answer = rag.search(question)

        st.subheader("답변")

        st.write(answer)