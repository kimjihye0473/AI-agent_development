import fitz
import faiss
import numpy as np

from sentence_transformers import SentenceTransformer

#클래스작성 
class RAGSystem:
    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.text_chunks = []
        self.index = None
#pdf 읽기 함수 추가
    def load_pdf(self, uploaded_file):
        pdf = fitz.open(stream=uploaded_file.read(), filetype="pdf")

        text = ""

        for page in pdf:
            text += page.get_text()

        pdf.close()

        return text

#문서 나누기 함수 
    def split_text(self, text, chunk_size=100):

        self.text_chunks = []

        for i in range(0, len(text), chunk_size):
            chunk = text[i:i+chunk_size]
            self.text_chunks.append(chunk)

        return self.text_chunks
    
#벡터 생성 함수
    def create_vector_db(self):

        embeddings = self.model.encode(self.text_chunks)

        dimension = embeddings.shape[1]

        self.index = faiss.IndexFlatL2(dimension)

        self.index.add(np.array(embeddings).astype("float32"))

#검색 함수 
    def search(self, question):

        question_embedding = self.model.encode([question])

        distance, index = self.index.search(
            np.array(question_embedding).astype("float32"),
            1
        )

        return self.text_chunks[index[0][0]]
